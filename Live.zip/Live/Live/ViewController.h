//
//  ViewController.h
//  Live
//
//  Created by user on 16/7/15.
//  Copyright © 2016年 Li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic)  UIButton *recordButton;
@property (strong, nonatomic)  UIView *previewView;

@end

